export interface Member {
  id: number;
  name: string;
  mail: string;
  tel: string;
  note?: string;
}